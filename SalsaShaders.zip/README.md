# SalsaShaders

A simple shaderpack for Minecraft.

Currently implements shadow mapping (poorly). Looks pretty cool, though.